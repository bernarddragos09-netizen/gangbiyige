import { Shield, Languages, Volume2, Database, Info, LogOut, History, ArrowLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function Settings() {
  return (
    <div className="max-w-2xl mx-auto space-y-12 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Header Section */}
      <div className="flex items-center gap-6 mb-8 border-b border-vantage-border pb-6">
        <Link to="/" className="text-white hover:text-brand-orange p-2 border border-vantage-border transition-colors">
          <ArrowLeft size={24} />
        </Link>
        <h2 className="text-4xl font-black uppercase tracking-tighter">用户设置</h2>
      </div>

      {/* Profile Hero */}
      <section className="vantage-card flex flex-col items-center text-center space-y-8 py-12 group relative overflow-hidden">
        <div className="vantage-glow opacity-5 transition-opacity"></div>
        <div className="relative">
          <div className="w-40 h-40 border border-brand-orange p-1 bg-brand-bg shadow-2xl overflow-hidden grayscale">
            <img 
               className="w-full h-full object-cover contrast-125 opacity-70 group-hover:opacity-100 transition-all duration-700"
               src="https://lh3.googleusercontent.com/aida-public/AB6AXuCZUvrD552oHfnv9zMMoGKHcsPTe_CnfwE-BVsPpqS0z12X4GI0Bp5YoxMtSHj6yJW9GNf2-sfAAAbu9rb4mEJX1b4a56n2s5-rdMqPwjKUOweEjef9EhzvP45mCyaTP5MR5DUQeWo1vdKbChS82DOx0qd1CAvGmNEhJXzIqBFibc1ZpJCSnAadca5hd1E7IjfHVrGnPkI0q80hgB1GGLlq1tpGusbrxa6m49Z4pdMg0FnztWFTZ76dzwOGCmuGLoPq9DhxOUFyGSEW" 
               alt="User"
            />
          </div>
          <div className="absolute -bottom-4 -right-4 bg-brand-orange text-white w-12 h-12 flex items-center justify-center font-black text-lg rotate-12 group-hover:rotate-0 transition-transform">
            印
          </div>
        </div>
        <div className="space-y-1">
          <h2 className="text-5xl font-black tracking-tighter uppercase mb-2">老李 / Vane.</h2>
          <span className="vantage-label text-brand-orange">文化传承人 • Level 42</span>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full max-w-sm space-y-4 mt-6">
          <div className="flex justify-between vantage-label opacity-40">
            <span>传承进度</span>
            <span>7,840 / 10,000 XP</span>
          </div>
          <div className="h-1 w-full bg-vantage-border overflow-hidden">
            <div className="h-full bg-brand-orange w-[78%] shadow-[0_0_8px_rgba(242,125,38,0.4)]"></div>
          </div>
        </div>
      </section>

      {/* Settings List */}
      <div className="space-y-4">
        <h3 className="vantage-label text-brand-orange px-2 flex items-center gap-3">
          <Shield size={14} /> 应用偏好
        </h3>
        <div className="divide-y divide-vantage-border border-y border-vantage-border">
          <SettingsItem icon={Shield} title="账号与安全" sub="访问密钥，逻辑验证" />
          <SettingsItem icon={Languages} title="方言映射" sub="主修语言：粤语" />
          <SettingsItem icon={Volume2} title="声音反馈" sub="播放速度，提醒" />
          <SettingsItem icon={Database} title="存储分配" sub="已用 124MB / 共 2GB" />
          <SettingsItem icon={Info} title="关于 / Vantage" sub="构建版本 2.4.1" />
        </div>
      </div>

      <div className="mt-16 flex flex-col items-center gap-8">
        <button className="px-12 py-4 bg-white text-black font-black uppercase tracking-widest text-[11px] hover:bg-brand-orange hover:text-white transition-all">
          退出当前会话
        </button>
        <span className="vantage-label italic opacity-30">Monolith Media Group © 2026</span>
      </div>

      <div className="mt-12 flex justify-center opacity-5">
        <div className="w-24 h-24 border-4 border-white flex items-center justify-center rotate-6">
          <History size={48} className="text-white" />
        </div>
      </div>
    </div>
  );
}

function SettingsItem({ icon: Icon, title, sub }: any) {
  return (
    <button className="w-full flex items-center justify-between py-8 px-6 group hover:bg-white/5 transition-all text-left">
      <div className="flex items-center gap-8">
        <div className="w-12 h-12 flex items-center justify-center text-brand-orange border border-vantage-border group-hover:border-brand-orange transition-all">
          <Icon size={20} />
        </div>
        <div className="space-y-1">
          <span className="block text-xl font-black uppercase tracking-tighter text-white group-hover:text-brand-orange transition-colors leading-none">{title}</span>
          <span className="block vantage-label opacity-40 group-hover:opacity-100 transition-opacity">{sub}</span>
        </div>
      </div>
      <ChevronRight className="text-vantage-muted group-hover:text-brand-orange group-hover:translate-x-2 transition-all" size={24} />
    </button>
  );
}
