import { Search, Bookmark, Volume2, Edit3, Book, Map, Quote, PlayCircle, CheckCircle2 } from "lucide-react";

export default function Dictionary() {
  return (
    <div className="max-w-screen-md mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-12">
      {/* Search Input */}
      <section>
        <div className="relative group">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-vantage-muted group-focus-within:text-brand-orange transition-colors" size={24} />
          <input
            type="text"
            className="w-full bg-brand-card border-none border-b border-vantage-border focus:border-brand-orange focus:ring-0 py-8 pl-16 pr-6 text-2xl font-light placeholder:vantage-muted transition-all uppercase tracking-[0.2em]"
            placeholder="搜索词典..."
          />
        </div>
      </section>

      {/* Selected Word Header */}
      <section className="p-12 vantage-card relative overflow-hidden group">
        <div className="vantage-glow group-hover:opacity-10 transition-opacity"></div>
        <div className="absolute top-8 right-8">
          <button className="text-brand-orange hover:scale-110 transition-transform">
            <Bookmark size={32} fill="currentColor" />
          </button>
        </div>
        <div className="flex flex-col items-center text-center">
          <div className="relative mb-8">
            <h2 className="vantage-heading-huge !text-9xl mb-0">囡囡</h2>
            <div className="absolute -top-4 -right-16 px-3 py-1 border border-brand-orange text-brand-orange font-black text-[10px] uppercase tracking-[0.4em] rotate-12">
              吴语
            </div>
          </div>
          <div className="flex items-center gap-8 mb-10">
            <span className="text-2xl font-serif italic text-vantage-muted">nā nā</span>
            <span className="vantage-label tracking-widest">[nø nⱘ]</span>
          </div>
          <div className="flex gap-8">
            <button className="w-48 py-4 bg-white text-black font-black uppercase tracking-widest text-[11px] hover:bg-brand-orange hover:text-white transition-all">
              发音
            </button>
            <button className="w-48 py-4 border border-vantage-border text-white font-black uppercase tracking-widest text-[11px] hover:border-white transition-all">
              注释
            </button>
          </div>
        </div>
      </section>

      {/* Definitions & Variations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="vantage-card space-y-6">
          <h3 className="vantage-label text-brand-orange border-b border-vantage-border pb-4 flex items-center gap-3">
            <Book size={18} /> 词义释意
          </h3>
          <ul className="space-y-6 text-vantage-text/80 font-serif italic text-lg leading-relaxed">
            <li className="flex gap-4">
              <span className="vantage-label text-brand-orange mt-1">01</span>
              <span>对小孩的亲昵称呼，包含深厚的情感。</span>
            </li>
            <li className="flex gap-4">
              <span className="vantage-label text-brand-orange mt-1">02</span>
              <span>泛指女儿；在城市语境中也是对年轻女性的亲密称呼。</span>
            </li>
          </ul>
        </div>
        <div className="vantage-card space-y-6">
          <h3 className="vantage-label text-brand-orange border-b border-vantage-border pb-4 flex items-center gap-3">
            <Map size={18} /> 地域差异
          </h3>
          <div className="space-y-4">
            <VariationRow dialect="上海" value="nøø nøø" detail="平调" />
            <VariationRow dialect="苏州" value="nie nie" detail="软糯" />
            <VariationRow dialect="宁波" value="nae nae" detail="厚重" />
          </div>
        </div>
      </div>

      {/* Example Sentences */}
      <section className="space-y-8">
        <h3 className="text-2xl font-black uppercase tracking-tighter flex items-center gap-4">
          <Quote className="rotate-180 text-brand-orange" size={24} /> 典型例句
        </h3>
        <div className="space-y-6">
          <ExampleCard
            text="“阿拉屋里囡囡老乖个。”"
            translation="我家的小宝贝非常乖巧。"
          />
          <ExampleCard
            text="“小囡囡，来吃颗糖。”"
            translation="乖宝宝，来吃个糖。"
            muted
          />
        </div>
      </section>

      {/* Mastery Status */}
      <div className="flex flex-col items-center pt-12">
        <button className="w-24 h-24 border border-vantage-border flex items-center justify-center group hover:border-brand-orange transition-all relative">
          <CheckCircle2 size={40} className="text-vantage-muted group-hover:text-brand-orange transition-colors" />
          <span className="absolute -bottom-10 vantage-label opacity-40 group-hover:opacity-100">已掌握</span>
        </button>
      </div>
    </div>
  );
}

function VariationRow({ dialect, value, detail }: any) {
  return (
    <div className="flex justify-between items-center pb-3 border-b border-vantage-border/50">
      <div className="flex flex-col">
        <span className="vantage-label text-[9px]">{dialect}</span>
        <span className="text-sm font-black tracking-widest">{value}</span>
      </div>
      <span className="text-[10px] font-serif italic text-vantage-muted">{detail}</span>
    </div>
  );
}

function ExampleCard({ text, translation, muted = false }: { text: string; translation: string; muted?: boolean }) {
  return (
    <div className={`p-8 vantage-card border-l-2 ${muted ? 'border-vantage-muted' : 'border-brand-orange'} flex justify-between items-center group`}>
      <div className="space-y-2">
        <p className="text-2xl font-black tracking-tight">{text}</p>
        <p className="text-vantage-muted italic font-serif">{translation}</p>
      </div>
      <button className="w-16 h-16 border border-vantage-border flex items-center justify-center group-hover:bg-brand-orange group-hover:text-white transition-all text-brand-orange">
        <PlayCircle size={32} />
      </button>
    </div>
  );
}
