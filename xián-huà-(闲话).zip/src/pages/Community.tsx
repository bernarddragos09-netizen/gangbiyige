import { Mic, Share2, Heart, MessageCircle, PlayCircle, MapPin } from "lucide-react";

export default function Community() {
  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Filter Tabs */}
      <div className="flex items-center gap-12 border-b border-vantage-border">
        <button className="pb-4 border-b-2 border-brand-orange text-white font-black uppercase tracking-widest text-xs">精选</button>
        <button className="pb-4 border-b-2 border-transparent text-vantage-muted font-bold uppercase tracking-widest text-xs hover:text-white transition-all">关注</button>
        <button className="pb-4 border-b-2 border-transparent text-vantage-muted font-bold uppercase tracking-widest text-xs hover:text-white transition-all">附近</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
        {/* Large Card */}
        <div className="md:col-span-8 vantage-card p-0 overflow-hidden group relative">
          <div className="absolute top-6 left-6 z-10">
            <div className="px-3 py-1 bg-brand-orange text-white text-[10px] uppercase font-black tracking-[0.3em] rotate-1">
              推荐
            </div>
          </div>
          <div className="aspect-[16/10] relative overflow-hidden">
            <img 
              className="w-full h-full object-cover grayscale opacity-50 group-hover:opacity-80 group-hover:grayscale-0 transition-all duration-700" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuA8g679dZGP6iD5bZ3Z0Gf5Qxe0QuMdjEPVCYA9zLbQqe1eP0CQoAFUA6RLgAhVfyk1-tpDa6EZAtbCKkIREPXN0Ms0ciAX10jh7KiHrtD-PIpI93QxOtIgyVD7Ju4ch1qm9Bcv8T8K6ZSQRjSxQ_DWAToeKFHeUUjkAlIPGpQW9aaUGEQB-MifbovFsarHe1_xw82SESvldLvxaX-AGKfQ4iMl5nowo5r5eiEAENzEI6LbEHxq9Wh83NVN5-pKfbols3XambAxsmuF" 
              alt="Chengdu Tea House"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-bg via-transparent to-black/20"></div>
            <div className="absolute bottom-8 left-8 flex items-center gap-4">
              <div className="w-12 h-12 border border-white p-0.5">
                <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuC0oMSLJxMOASdPNyWtwFJobOzu9l1HI7BctF1QgNbpVHPDCHXuN7nQ28gDwSIFEYa9jXdQw6GhiYegA7Md0rFf6YP07ZZcuQrGS8Z65JcU08sCQtlwBznVESdm-gCY_RC43z-xzwH40OVNMEVRRG2pXpm4cmDpi9R94d3ZSEqC3P7jg8SyuxCL1no69SkD8icYCtBJVDbKzQe3nhft0IE9_AvBZh8dNlpfbytOriviDbX1qzClJUSc2UbGvQn92uTx5peQDwUitWW-" alt="User" />
              </div>
              <div>
                <p className="font-black uppercase tracking-tighter text-lg">老李在茶馆</p>
                <span className="vantage-label text-brand-orange">四川话 · 成都</span>
              </div>
            </div>
          </div>
          <div className="p-8">
            <h3 className="text-3xl font-black uppercase tracking-tighter mb-4 mix-blend-difference">盖碗茶里的龙门阵</h3>
            <p className="text-vantage-muted italic font-serif leading-relaxed mb-8">今日，我们走进成都茶馆的市井回响。这种深沉的方言，诉说着城市的灵魂...</p>
            <div className="flex items-center justify-between pt-6 border-t border-vantage-border">
              <div className="flex gap-8">
                <SocialButton icon={Heart} count="1.2k" active />
                <SocialButton icon={MessageCircle} count="86" />
              </div>
              <button className="vantage-label text-brand-orange hover:text-white flex items-center gap-2 group transition-colors">
                查看详情 <PlayCircle size={18} className="group-hover:scale-110 transition-transform" />
              </button>
            </div>
          </div>
        </div>

        {/* Side Stack */}
        <div className="md:col-span-4 space-y-10">
          <AudioPost 
            user="阿敏的小调" 
            dialect="闽南语" 
            text="&quot;天黑黑，欲落雨...&quot;"
            location="厦门 · 3分钟前"
          />
          <VisualCard 
            title="苏州评弹：初听不知曲中意"
            views="428 次阅读"
            img="https://lh3.googleusercontent.com/aida-public/AB6AXuCbIHYq64bK6GKao7CVehK6XG5ZUbKyAHr3i25l5UnbwXGVsa-2urBySGzptKPyVGo_YqyG2RtFGt9ccouYb5NuBE0HMqC8X7QXkjAY-nAaOQ06bTrGkUqyCRlzKHLRK-LzkVqb35hmoRtcPOqdOOO7PqY3EndPnbhjzgGnLnB8Y2x0ekb0lRGfepi6FfYJ8BxNFwB7qzAcxM_4fctArT0VlMnJ9JDW5feQMq0gcZ40Ju0O09CFUGyS5-TOfLuxxWr0Vgg60XX5C5BJ"
          />
        </div>

        {/* Longer Post Feed */}
        <div className="md:col-span-12 space-y-8">
           <LongPost 
             user="林间风" 
             dialect="北京话" 
             location="东城区"
             title="胡同里的叫卖声"
             desc="探寻老北京胡同里失落的旋律。一场关于街道声学与文化记忆的深刻旅程。"
             img="https://lh3.googleusercontent.com/aida-public/AB6AXuCCPlaIKr1lRPIaE2FKtNG2GbY1px9SJ0sfL-1e_16QncYxwKk-Hrt176qK5jOU11-4F17xNcJZMUDyuAHMY-8Oh0C1A5N6k0dd3tgMIB7mT_a1oj2S3fmVK1mfkCz0Q0u-W60eTabMHJKXZO-Pb_l-H5hMYDH7aeDEi1E6gkEukejCNxgT-q8TIxhmr3hww0YuW8L5mFfiDW71hvznEFVxvPljtXMXYiA5-wZdWiLiuCJODPVl8eehsen-F4SMUGAqhLIiLfwEs3AJ"
             userImg="https://lh3.googleusercontent.com/aida-public/AB6AXuABbwqWxP66DZc0JUyGief8WxRRrdIsJBiG-5lD_e_kV8aWJSpfn2VNO8kF9qCaMmTWHBEs4Wp1EVjVIXNs_h1sOEtny5rO6rSqZAbxh8uBo8Z-AGrekEhQBtqqp_co5XB2XaULApFTxo0NWfQ4k6LdmAneff98HlPom5aN2yQILwaQkJqzeIPnCuO6dV9limnsVDmtXjJnCTnmCxGX0xXvbxIjpfJdByVYcv-bX3eDURrm42-aRk6aKV7i_O1aXCpK2EngYUPU9jVE"
           />
        </div>
      </div>
    </div>
  );
}

function SocialButton({ icon: Icon, count, active = false }: { icon: any; count: string; active?: boolean }) {
  return (
    <button className="flex items-center gap-2 text-vantage-muted hover:text-white transition-colors">
      <Icon size={18} fill={active ? "currentColor" : "none"} className={active ? "text-brand-orange" : ""} />
      <span className="vantage-label text-[9px]">{count}</span>
    </button>
  );
}

function AudioPost({ user, dialect, text, location }: any) {
  return (
    <div className="vantage-card relative overflow-hidden group">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 border border-brand-orange flex items-center justify-center text-brand-orange">
            <Mic size={16} />
          </div>
          <span className="text-xs font-black uppercase tracking-widest">{user}</span>
        </div>
        <span className="vantage-label text-brand-orange">{dialect}</span>
      </div>
      <div className="h-10 flex items-end gap-1 mb-6">
        {[0.4, 0.8, 0.6, 1.0, 0.5, 0.7, 0.3].map((h, i) => (
          <div key={i} className="flex-1 bg-white group-hover:bg-brand-orange transition-colors" style={{ height: `${h * 100}%`, opacity: h * 0.5 }}></div>
        ))}
      </div>
      <p className="text-sm italic font-serif text-vantage-muted mb-6">{text}</p>
      <div className="flex items-center justify-between vantage-label opacity-40">
        <span>{location}</span>
        <Share2 size={12} className="cursor-pointer hover:text-white" />
      </div>
    </div>
  );
}

function VisualCard({ title, views, img }: any) {
  return (
    <div className="vantage-card p-0 overflow-hidden group cursor-pointer">
      <div className="h-40 relative">
        <img className="w-full h-full object-cover grayscale opacity-40 group-hover:opacity-100 group-hover:grayscale-0 transition-all duration-700" src={img} alt={title} />
        <div className="absolute inset-0 bg-brand-orange/10"></div>
      </div>
      <div className="p-6 space-y-4">
        <p className="font-black uppercase tracking-tighter text-sm line-clamp-1">{title}</p>
        <div className="flex justify-between items-center pb-2 border-b border-vantage-border">
          <span className="vantage-label opacity-50">{views}</span>
          <PlayCircle size={16} className="text-brand-orange" />
        </div>
      </div>
    </div>
  );
}

function LongPost({ user, dialect, location, title, desc, img, userImg }: any) {
  return (
    <div className="vantage-card p-0 overflow-hidden flex flex-col md:flex-row gap-0 group cursor-pointer hover:border-white transition-all">
      <div className="w-full md:w-64 h-full relative overflow-hidden shrink-0">
        <img src={img} className="w-full h-full object-cover grayscale opacity-50 group-hover:opacity-100 group-hover:grayscale-0 transition-all duration-700" alt={title} />
      </div>
      <div className="flex flex-col justify-between flex-1 p-8">
        <div>
          <div className="flex items-center gap-3 mb-6">
            <img src={userImg} className="w-6 h-6 border border-vantage-border" alt={user} />
            <span className="text-xs font-black uppercase tracking-widest">{user}</span>
            <span className="vantage-label">• {dialect}</span>
          </div>
          <h4 className="text-4xl font-black tracking-tighter uppercase leading-none mb-4 group-hover:text-brand-orange transition-colors">{title}</h4>
          <p className="text-vantage-muted italic font-serif text-sm line-clamp-2 max-w-xl">{desc}</p>
        </div>
        <div className="flex items-center gap-12 mt-8 vantage-label opacity-40">
          <span className="flex items-center gap-2"><Heart size={14} /> 342</span>
          <span className="flex items-center gap-2"><MessageCircle size={14} /> 12</span>
          <span className="flex items-center gap-2 tracking-widest"><MapPin size={14} /> {location}</span>
        </div>
      </div>
    </div>
  );
}
