import { MapPin, Volume2, Music, BookOpen, PenTool, ChevronLeft, ChevronRight, Compass } from "lucide-react";
import { motion } from "motion/react";

export default function Explore() {
  return (
    <div className="space-y-20 pb-12">
      {/* Welcome & Search */}
      <section className="space-y-8">
        <div>
          <span className="vantage-label text-brand-orange">探索 / 前言</span>
          <h2 className="vantage-heading-huge">家乡<br/>回响.</h2>
          <p className="text-xl font-serif italic text-vantage-muted mt-4 max-w-lg">探索古老方言与现代数字人文的交汇点。</p>
        </div>
        <div className="relative group max-w-xl">
          <input
            type="text"
            className="w-full bg-transparent border-b border-vantage-border focus:border-brand-orange outline-none py-6 px-0 text-2xl font-light placeholder:vantage-muted transition-all uppercase tracking-widest"
            placeholder="搜索方言..."
          />
          <div className="absolute right-0 top-1/2 -translate-y-1/2 text-brand-orange">
            <MapPin size={24} />
          </div>
        </div>
      </section>

      {/* Dialect Map Section */}
      <section className="space-y-6">
        <div className="flex justify-between items-end border-b border-vantage-border pb-4">
          <div className="flex items-center gap-4">
            <h3 className="text-2xl font-black uppercase tracking-tighter">方言图谱</h3>
            <span className="vantage-label">Vol 01</span>
          </div>
          <span className="vantage-label text-brand-orange hover:text-white cursor-pointer transition-colors">查看档案</span>
        </div>
        <div className="relative overflow-hidden bg-brand-card aspect-[21/9] border border-vantage-border group">
          <div className="vantage-glow group-hover:opacity-20 transition-opacity"></div>
          <img
            alt="Dialect Map"
            className="w-full h-full object-cover opacity-40 grayscale group-hover:grayscale-0 transition-all duration-700"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuD1_8eS0iJmYL9y_FpG1r24i3N66RJaaCKsxX97z96VWad6kzen9maXuANc7dxF-bNU32zYAEYRiMvKPyl8cxQR_M0vRxatq1_mvQIh9QyTF7jSrGpVF0KRfjT7qpoXJX3uRB81bFBzhlon9VfQQGsPzUfUnH5qXiaoGeP40PXlLDcEEoKNYw198wQH4adh0HpKLg6nI6u9oTa_jQsK5AeEdp4-nPXiOVfUkeMu8jgSVJfz_oD3t_8wohosasYjmjVrDwifkraxlSMP"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-bg via-transparent to-transparent"></div>
          <div className="absolute bottom-8 left-10 space-y-2">
            <span className="vantage-label text-brand-orange">热门 / 吴语</span>
            <p className="text-4xl font-light italic font-serif">枕河人家：吴语图鉴</p>
          </div>
          <div className="absolute top-8 right-10">
            <button className="w-16 h-16 bg-white text-black flex items-center justify-center hover:bg-brand-orange hover:text-white transition-colors">
              <Compass size={32} />
            </button>
          </div>
        </div>
      </section>

      {/* Daily Word & Bento Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Daily Word Card */}
        <div className="lg:col-span-5 vantage-card relative overflow-hidden flex flex-col justify-between min-h-[400px]">
          <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/5 rounded-full blur-3xl"></div>
          <div className="space-y-6">
            <span className="vantage-label text-brand-orange">每日 / 粤语</span>
            <div className="space-y-2">
              <h4 className="text-8xl font-black text-white tracking-tighter">闭翳</h4>
              <p className="text-vantage-muted font-mono tracking-widest opacity-60">BAI3 AI3</p>
            </div>
          </div>
          <div className="flex items-center gap-8">
            <button className="w-20 h-20 bg-white text-black flex items-center justify-center hover:bg-brand-orange hover:text-white transition-colors">
              <Volume2 size={36} />
            </button>
            <div className="space-y-2 border-l border-brand-orange pl-6">
              <p className="text-2xl font-serif italic text-white leading-tight">发愁，令人忧心</p>
              <p className="vantage-label opacity-50">“真系令人闭翳咯。”</p>
            </div>
          </div>
        </div>

        {/* Featured Sections */}
        <div className="lg:col-span-7 grid grid-cols-2 gap-8">
          <FeaturedItem 
            icon={Music} 
            title="江南评弹" 
            desc="聆听吴侬软语的细腻音韵。" 
          />
          <FeaturedItem 
            icon={BookOpen} 
            title="方言俚语" 
            desc="在城市街道中探寻方言智慧。" 
          />
          <div className="col-span-2 bg-brand-orange p-10 flex items-center justify-between group cursor-pointer hover:bg-white hover:text-black transition-colors duration-500">
            <div className="max-w-[70%]">
              <span className="vantage-label text-black/40 font-black">雅集</span>
              <h5 className="text-3xl font-black uppercase tracking-tighter mt-2">我的乡音 / 全民征集</h5>
              <p className="text-sm font-medium mt-4 opacity-80 leading-relaxed italic">上传您的方言朗读，赢取专属数字印章。</p>
            </div>
            <div className="w-24 h-24 border border-current rounded-full flex items-center justify-center rotate-12 group-hover:rotate-0 transition-transform">
              <PenTool size={48} />
            </div>
          </div>
        </div>
      </div>

      {/* Featured Stories */}
      <section className="space-y-10">
        <div className="flex justify-between items-center border-b border-vantage-border pb-6">
          <div className="flex items-center gap-4">
            <h3 className="text-2xl font-black uppercase tracking-tighter">志异专栏</h3>
            <span className="vantage-label">第四辑</span>
          </div>
          <div className="flex gap-4">
            <button className="w-12 h-12 border border-vantage-border flex items-center justify-center text-vantage-muted hover:text-white hover:border-white transition-all">
              <ChevronLeft size={20} />
            </button>
            <button className="w-12 h-12 border border-vantage-border flex items-center justify-center text-vantage-muted hover:text-white hover:border-white transition-all">
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-white">
          <StoryCard
            tag="广东"
            title="饮咗茶未？粤语中的早茶社交"
            img="https://lh3.googleusercontent.com/aida-public/AB6AXuD98HS_EHyWpr-0riDgrHtAN20A3FgxlhGCYvWab3XXESTxehBUWyvR-x8hiILGFM681ZYsZbpwBLnsLDajQoP-_mAscDiQt7A7ourFlVPPf8iFbQg65lUj5z4KUjfdMQThMUUOAzSp1CivlYwOOTeMTCRrdWnKziBRcJQso6xtbkCX4AJGtKv-OfY24w1LwCZ0GE5RGDQwuLmtkN2V1y1OtJNQipe8x0mDhTqKQeG4BBdKJtXWRSeLD8ZsO1kTHcju-5zJxCbqOpsp"
          />
          <StoryCard
            tag="北京"
            title="北京话里的“儿”化音美学"
            img="https://lh3.googleusercontent.com/aida-public/AB6AXuBQSU4U1eCXmtn4D9DBlOlMWbl1tAzfxQkLruuyX4Zhkuhuu7wgm6eVEynixvfhRKjJCTYKv7DG4iwCnAbD41QDYm29fM3rdmVHXW3J-TVZgguslliFrm2KowRmsP1oHAin4jrlUWFntjgmPR69VdMI66Yc2sNdL91gsnUZuVayJ0JRonTW2C7AaMN_R2KXrtuw6p0XBXFPW1gIcmno786c8NoFar5VHUnbdYJ8RRai-TucgqqyZiGxqJR_lKDr39hCL0U-slwNfuxO"
          />
          <StoryCard
            tag="四川"
            title="变脸之外：四川方言的幽默感"
            img="https://lh3.googleusercontent.com/aida-public/AB6AXuBTZkW1imp4TRUmfGGPTlCpcH5W2HbDtS7mIwuwC-2S5mD9o6USZNCaS2KhSfoDgFK_CwZYUNTQgWsQyGjnHbg7b61JUdoUopiPzs-NLilYPQMLPkyXI0MCNdr6oE3BrptW1y770y3LLOo6pYOjSVAlcrjxmSRSb8SvBSfTXrdXxj1yLgCUv2_C4TGzmO1494Xh2ypQNpY6A4IlpC_PbXSNtYeY069PuZY4Sb1AqGvdLB5ZeutKYK4IDYz2mjqovH3CS5kU_CH5yP6Z"
          />
        </div>
      </section>
    </div>
  );
}

function FeaturedItem({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="vantage-card group cursor-pointer hover:bg-brand-bg transition-all flex flex-col justify-between aspect-square">
      <Icon className="text-brand-orange" size={32} />
      <div className="space-y-2">
        <h5 className="text-xl font-black uppercase tracking-tighter text-white">{title}</h5>
        <p className="text-sm italic font-serif text-vantage-muted line-clamp-2">{desc}</p>
      </div>
    </div>
  );
}

function StoryCard({ tag, title, img }: { tag: string; title: string; img: string }) {
  return (
    <div className="space-y-6 group cursor-pointer">
      <div className="aspect-[4/5] relative overflow-hidden bg-brand-card border border-vantage-border">
        <img
          alt={title}
          className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700 opacity-60 group-hover:opacity-100"
          src={img}
        />
        <div className="absolute inset-0 bg-brand-orange/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
      </div>
      <div className="space-y-2">
        <span className="vantage-label text-brand-orange">{tag}</span>
        <h6 className="text-2xl font-black tracking-tighter leading-tight uppercase transition-colors">{title}</h6>
      </div>
    </div>
  );
}
