import { Play, Ear, Mic, RotateCcw, Share2, Award, Brush, BookOpen, Trophy } from "lucide-react";

export default function Practice() {
  return (
    <div className="max-w-screen-md mx-auto space-y-12 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Progress Header */}
      <section className="space-y-6">
        <div className="flex justify-between items-end border-b border-vantage-border pb-4">
          <div>
            <span className="vantage-label text-brand-orange">训练 / 等级 04</span>
            <h2 className="text-4xl font-black uppercase tracking-tighter mt-2">吴语初探</h2>
          </div>
          <div className="text-right">
            <span className="text-3xl font-black tracking-tighter">1,240 <span className="vantage-label !text-xs opacity-40">pts</span></span>
          </div>
        </div>
        <div className="w-full h-1 bg-vantage-border overflow-hidden">
          <div className="h-full bg-brand-orange w-2/3 shadow-[0_0_10px_rgba(242,125,38,0.5)]"></div>
        </div>
      </section>

      {/* Challenge 1: Hear & Differentiate */}
      <section className="space-y-8">
        <div className="flex items-center gap-4">
          <Ear className="text-brand-orange" size={24} />
          <h3 className="text-2xl font-black uppercase tracking-tighter">听音辨义</h3>
        </div>
        <div className="vantage-card space-y-12 p-12">
          <div className="flex flex-col items-center gap-8">
            <button className="w-24 h-24 bg-white text-black flex items-center justify-center hover:bg-brand-orange hover:text-white transition-colors group">
              <Play size={48} fill="currentColor" className="group-hover:scale-110 transition-transform" />
            </button>
            <div className="w-full h-16 flex items-end justify-center gap-2">
              {[0.2, 0.4, 0.6, 0.3, 0.5, 1.0, 0.4, 0.2, 0.5, 0.8].map((height, i) => (
                <div key={i} className="flex-1 bg-brand-orange" style={{ height: `${height * 100}%`, opacity: height * 0.7 }}></div>
              ))}
            </div>
            <span className="vantage-label">解析苏州话音频片段</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Option label="01" text="依好 (你好)" />
            <Option label="02" text="阿拉 (我们)" active />
            <Option label="03" text="伐晓得 (不知道)" />
            <Option label="04" text="汏浴 (洗澡)" />
          </div>
        </div>
      </section>

      {/* Challenge 2: Speaking */}
      <section className="space-y-8">
        <div className="flex items-center gap-4">
          <Mic className="text-brand-orange" size={24} />
          <h3 className="text-2xl font-black uppercase tracking-tighter">跟读挑战</h3>
        </div>
        <div className="vantage-card p-12 flex flex-col items-center text-center space-y-12">
          <div className="space-y-4">
            <span className="vantage-label text-brand-orange">上海话 / 档案条目</span>
            <h4 className="text-5xl font-black uppercase tracking-tight italic font-serif">“侬饭吃过了伐？”</h4>
            <p className="text-vantage-muted tracking-widest text-sm opacity-60">Nóng vé qi-gu lē vá?</p>
          </div>

          <div className="relative w-40 h-40 flex items-center justify-center group">
            <div className="vantage-glow opacity-0 group-hover:opacity-10 transition-opacity"></div>
            <svg className="absolute inset-0 w-full h-full -rotate-90">
              <circle className="text-vantage-border" cx="80" cy="80" fill="none" r="76" stroke="currentColor" strokeWidth="2" />
              <circle className="text-brand-orange" cx="80" cy="80" fill="none" r="76" stroke="currentColor" strokeDasharray="477" strokeDashoffset="50" strokeWidth="4" />
            </svg>
            <div className="flex flex-col items-center">
              <span className="text-5xl font-black tracking-tighter text-white">89</span>
              <span className="vantage-label !text-[8px]">精准度</span>
            </div>
          </div>

          <div className="flex items-center gap-12">
            <IconButton icon={RotateCcw} />
            <button className="w-24 h-24 bg-brand-orange text-white flex items-center justify-center hover:bg-white hover:text-black transition-all">
              <Mic size={48} fill="currentColor" />
            </button>
            <IconButton icon={Share2} />
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="space-y-8">
        <div className="flex items-center justify-between border-b border-vantage-border pb-4">
          <div className="flex items-center gap-4">
            <Award className="text-brand-orange" size={24} />
            <h3 className="text-2xl font-black uppercase tracking-tighter">勋章与奖励</h3>
          </div>
          <button className="vantage-label hover:text-white transition-colors">查看全部画廊</button>
        </div>
        <div className="grid grid-cols-4 gap-8">
          <Badge icon={Award} label="初出茅庐" active />
          <Badge icon={Brush} label="墨香四溢" />
          <Badge icon={BookOpen} label="博闻强记" active />
          <Badge icon={Trophy} label="方言专家" active />
        </div>
      </section>
    </div>
  );
}

function Option({ label, text, active = false }: { label: string; text: string; active?: boolean }) {
  return (
    <button className={`flex items-center p-6 border transition-all text-left group ${active ? 'border-brand-orange bg-brand-orange/10' : 'border-vantage-border hover:border-white'}`}>
      <span className={`w-10 h-10 flex items-center justify-center text-xs font-black mr-6 ${active ? 'bg-brand-orange text-white' : 'border border-vantage-border text-vantage-muted group-hover:text-white'}`}>{label}</span>
      <span className="text-lg font-black uppercase tracking-tight">{text}</span>
    </button>
  );
}

function IconButton({ icon: Icon }: { icon: any }) {
  return (
    <button className="w-14 h-14 flex items-center justify-center border border-vantage-border text-vantage-muted hover:text-white hover:border-white transition-colors">
      <Icon size={24} />
    </button>
  );
}

function Badge({ icon: Icon, label, active = false }: { icon: any; label: string; active?: boolean }) {
  return (
    <div className="flex flex-col items-center gap-4 group">
      <div className={`w-20 h-20 flex items-center justify-center transition-all group-hover:scale-110 cursor-help ${active ? 'bg-brand-orange text-white' : 'bg-brand-card border border-vantage-border text-vantage-muted opacity-30 grayscale'}`}>
        <Icon size={36} fill={active ? "currentColor" : "none"} />
      </div>
      <span className={`vantage-label text-center ${active ? 'text-white' : ''}`}>{label}</span>
    </div>
  );
}
