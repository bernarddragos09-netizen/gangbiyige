import { Compass, BookText, GraduationCap, Users } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/src/lib/utils";

const NAV_ITEMS = [
  { id: "explore", label: "探索", icon: Compass, path: "/" },
  { id: "dict", label: "词典", icon: BookText, path: "/dictionary" },
  { id: "practice", label: "练习", icon: GraduationCap, path: "/practice" },
  { id: "community", label: "雅集", icon: Users, path: "/community" },
];

export default function BottomNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 w-full z-50 bg-brand-bg/90 backdrop-blur-xl border-t border-vantage-border pb-safe">
      <div className="flex justify-around items-center h-20 w-full px-8">
        {NAV_ITEMS.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <Link
              key={item.id}
              to={item.path}
              className={cn(
                "flex flex-col items-center justify-center px-4 py-2 transition-all duration-300 ease-out",
                isActive 
                  ? "text-brand-orange border-b-2 border-brand-orange" 
                  : "text-vantage-muted hover:text-white"
              )}
            >
              <Icon size={22} strokeWidth={isActive ? 2.5 : 2} />
              <span className="vantage-label mt-2 tracking-[0.2em]">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
