import { Settings, Search, User } from "lucide-react";
import { Link } from "react-router-dom";

export default function TopBar() {
  return (
    <header className="fixed top-0 w-full z-50 bg-brand-bg/80 backdrop-blur-xl border-b border-vantage-border">
      <div className="flex justify-between items-center px-10 h-20 w-full max-w-screen-xl mx-auto">
        <div className="flex flex-col">
          <h1 className="text-2xl font-black tracking-tighter leading-none text-white uppercase">VANTAGE.</h1>
          <span className="vantage-label mt-1 text-brand-orange">闲话 / 第零一辑</span>
        </div>
        <div className="flex items-center gap-6">
          <button className="w-10 h-10 flex items-center justify-center rounded-full text-vantage-muted hover:text-white transition-all">
            <Search size={22} />
          </button>
          <Link to="/settings" className="w-10 h-10 flex items-center justify-center rounded-full text-vantage-muted hover:text-white transition-all border border-vantage-border">
            <Settings size={20} />
          </Link>
        </div>
      </div>
    </header>
  );
}
