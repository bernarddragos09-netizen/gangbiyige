import { Outlet } from "react-router-dom";
import TopBar from "./TopBar";
import BottomNav from "./BottomNav";
import { Plus } from "lucide-react";

export default function Layout() {
  return (
    <div className="min-h-screen bg-brand-bg dot-grid pb-32">
      <TopBar />
      <main className="max-w-screen-xl mx-auto px-10 pt-32">
        <Outlet />
      </main>
      <BottomNav />
      
      {/* Floating Action Button */}
      <div className="fixed bottom-28 right-10 z-40">
        <button className="w-16 h-16 bg-white text-black flex items-center justify-center transition-all hover:bg-brand-orange hover:text-white group relative">
          <Plus size={32} />
          <div className="absolute right-20 bg-brand-card border border-vantage-border px-4 py-2 rounded-none opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-2xl pointer-events-none">
            <span className="vantage-label text-white">记录乡音</span>
          </div>
        </button>
      </div>
    </div>
  );
}
